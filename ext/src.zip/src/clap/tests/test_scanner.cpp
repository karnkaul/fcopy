import clap.detail;

#include "klib/unit_test/unit_test.hpp"

namespace {
using namespace std::string_view_literals;

using namespace clap;

using Token = detail::ScannerToken;
using detail::Scanner;

TEST_CASE(scanner_empty) {
	auto scanner = Scanner{{}};
	auto token = Token{};
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_strings) {
	static constexpr auto words = std::array{
		"foo"sv,
		"bar"sv,
		"fubar"sv,
	};
	auto scanner = Scanner{words};
	auto token = Token{};
	for (auto const word : words) {
		EXPECT(scanner.scan_next(token));
		EXPECT(token.type == Token::Type::String);
		EXPECT(word == token.lexeme);
	}
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_empty_argument) {
	static constexpr auto words = std::array{""sv};
	auto scanner = Scanner{words};
	auto token = Token{};

	EXPECT(!scanner.at_end());
	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::String);
	EXPECT(token.lexeme.empty());
	EXPECT(scanner.at_end());
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_empty_argument_between_words) {
	static constexpr auto words = std::array{"before"sv, ""sv, "after"sv};
	auto scanner = Scanner{words};
	auto token = Token{};

	EXPECT(scanner.scan_next(token));
	EXPECT(token.lexeme == "before");
	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::String);
	EXPECT(token.lexeme.empty());
	EXPECT(scanner.scan_next(token));
	EXPECT(token.lexeme == "after");
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_trailing_empty_argument) {
	static constexpr auto words = std::array{"before"sv, ""sv};
	auto scanner = Scanner{words};
	auto token = Token{};

	EXPECT(scanner.scan_next(token));
	EXPECT(token.lexeme == "before");
	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::String);
	EXPECT(token.lexeme.empty());
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_mm_string) {
	static constexpr auto words = std::array{
		"--foo"sv,
		"--bar"sv,
		"--fubar"sv,
	};
	auto scanner = Scanner{words};
	auto token = Token{};
	for (auto const word : words) {
		EXPECT(scanner.scan_next(token));
		EXPECT(token.type == Token::Type::MinusMinusString);
		EXPECT(word == token.lexeme);
	}
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_m_string) {
	static constexpr auto words = std::array{
		"-foo"sv,
		"-b"sv,
		"-fubar"sv,
	};
	auto scanner = Scanner{words};
	auto token = Token{};
	for (auto const word : words) {
		EXPECT(scanner.scan_next(token));
		EXPECT(token.type == Token::Type::MinusString);
		EXPECT(word == token.lexeme);
	}
	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_mm_string_value) {
	static constexpr auto words = std::array{
		"--foo=bar"sv,
		"--fubar=42"sv,
	};
	auto scanner = Scanner{words};
	auto token = Token{};

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusMinusString);
	EXPECT(token.lexeme == "--foo=bar");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusMinusString);
	EXPECT(token.lexeme == "--fubar=42");

	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_m_string_value) {
	static constexpr auto words = std::array{
		"-foo=bar"sv,
		"-fubar=42"sv,
	};
	auto scanner = Scanner{words};
	auto token = Token{};

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusString);
	EXPECT(token.lexeme == "-foo=bar");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusString);
	EXPECT(token.lexeme == "-fubar=42");

	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}

TEST_CASE(scanner_all) {
	static constexpr auto words = std::array{
		"-f"sv,
		"cmd"sv,
		"--flag"sv,
		"-fabc"sv,
		"-fabc=42"sv,
		"arg"sv,
		"--"sv,
		"-arg"sv,
	};
	auto scanner = Scanner{words};
	auto token = Token{};

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusString);
	EXPECT(token.lexeme == "-f");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::String);
	EXPECT(token.lexeme == "cmd");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusMinusString);
	EXPECT(token.lexeme == "--flag");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusString);
	EXPECT(token.lexeme == "-fabc");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusString);
	EXPECT(token.lexeme == "-fabc=42");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::String);
	EXPECT(token.lexeme == "arg");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusMinus);
	EXPECT(token.lexeme == "--");

	EXPECT(scanner.scan_next(token));
	EXPECT(token.type == Token::Type::MinusString);
	EXPECT(token.lexeme == "-arg");

	EXPECT(!scanner.scan_next(token));
	EXPECT(token.type == Token::Type::Eof);
}
} // namespace
